public class Lehrer {
    private String name;
    private String kuerzel;

    public Lehrer(String name, String kuerzel) {
        this.name = name;
        this.kuerzel = kuerzel;
    }

    public String getName() {
        return name;
    }

    public String getKuerzel() {
        return kuerzel;
    }
}
