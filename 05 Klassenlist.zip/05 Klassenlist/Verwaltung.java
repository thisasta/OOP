import java.util.Scanner;

public class Verwaltung {
    private Klasse meineKlasse;

    public Verwaltung() {
        meineKlasse = new Klasse();
    }

    public void eingabe() {
        Scanner scn = new Scanner(System.in);
        System.out.println("Klassenbezeichnung: ");
        meineKlasse.setName(scn.nextLine());
        System.out.println("Name des Tutors: ");
        String tutorName = scn.nextLine();
        System.out.println("Kürzel des Tutors: ");
        meineKlasse.setMeinTutor(new Lehrer(tutorName, scn.nextLine()));
        String cont = "j";
        do {
            System.out.println("\nName des Schuelers: ");
            meineKlasse.neuerSchuelerHinzufuegen(scn.nextLine());
            System.out.println("\nWollen sie einen weiteren Schüler anlegen? (Ja: j, Nein: n)");
            cont = scn.nextLine();
        }while(cont.equalsIgnoreCase("j"));
    }

    public void menue() {
        int menueI;
        do {
        System.out.println("1: Neue Klasse anlegen\n2: Ausgabe der Daten der Klasse\n0: Programm schließen");
        Scanner scn = new Scanner(System.in);
        menueI = scn.nextInt();
            switch (menueI) {
                case 1:
                    eingabe();
                    break;
                case 2:
                    ausgabe();
                    break;
                case 0:
                    System.exit(0);
                    break;
            }
        }while (menueI != 0);

    }

    public void ausgabe() {
        System.out.println("Klassenbezeichnung: " + meineKlasse.getName());
        System.out.println("Tutor: " + meineKlasse.getMeinTutor().getName() + "(" + meineKlasse.getMeinTutor().getKuerzel() + ")");

        int i = 1;
        for (Schueler tempS: meineKlasse.getMeineSchueler()){
            System.out.println(i + ". " + tempS.getName());
            i++;
        }
    }

    public static void main(String[] args) {
        Verwaltung v = new Verwaltung();
        v.menue();
    }
}
