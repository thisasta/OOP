import java.util.ArrayList;

public class Klasse {
    private String name;
    private ArrayList <Schueler> meineSchueler;
    private Lehrer meinTutor;

    public Klasse() {
        meineSchueler = new ArrayList<Schueler>();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<Schueler> getMeineSchueler() {
        return meineSchueler;
    }

    public void setMeineSchueler(ArrayList<Schueler> meineSchueler) {
        this.meineSchueler = meineSchueler;
    }

    public void neuerSchuelerHinzufuegen(String name) {
        meineSchueler.add(new Schueler(name));
    }

    public void setMeinTutor(Lehrer meinTutor) {
        this.meinTutor = meinTutor;
    }

    public Lehrer getMeinTutor() {
        return meinTutor;
    }

    public ArrayList<String> ausgabeSchuelerNamen() {
        ArrayList<String> tempNamen = new ArrayList<String>();
        for (Schueler tempS:
             meineSchueler) {
            tempNamen.add(tempS.getName());
        }
        return tempNamen;
    }
}
